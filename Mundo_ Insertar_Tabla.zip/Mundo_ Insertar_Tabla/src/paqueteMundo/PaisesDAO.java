/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqueteMundo;

import java.sql.*;

/**
 *
 * @author Alumno
 */
public class PaisesDAO {
    
    private Connection conector = null;
    private PreparedStatement comando = null;
    
    private String SQL="";
    
    private void abrir() {
        try {
              conector = DriverManager.getConnection("jdbc:mysql://localhost/mundo", "root", "");
        }catch(SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    private void cerrar() {
        try {
            conector.close();
        }catch(SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    public boolean grabar(PaisesVO p) {
        boolean ok = true;
        
        SQL = "INSERT INTO paises VALUES(?, ?, ?)";
        
        this.abrir();
        
        try {
            comando = conector.prepareStatement(SQL);
            comando.setInt(1, p.getPais());
            comando.setString(2, p.getNombre());
            comando.setInt(3, p.getMillones());
            comando.executeUpdate();
            
        }catch(SQLException ex) {
            ok = false;
        }
       
        this.cerrar();
        
        return ok;
        
    }
    
    public void listar() {
        /*
        String palabras[] = {"TECLADO", "MOUSE", "MONITOR"};
        
        for(String palabra : palabras) {
            System.out.println(palabra);
        }
        */
        
        SQL = "SELECT pais, nombre, millones FROM paises ORDER BY pais";
        
        this.abrir();
        
         try {
            comando = conector.prepareStatement(SQL);
            ResultSet rs = comando.executeQuery(SQL);
            while(rs.next()) {
                System.out.println(rs.getString("nombre"));
            }
        }catch(SQLException ex) {
           
        }
           
        this.cerrar();
    }
    
}
