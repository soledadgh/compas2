/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import modelo.ProductoDAO;
import modelo.ProductoVO;
import vista.ProductoVista;

/**
 *
 * @author mec
 */
public class ProductoControlador implements ActionListener {
    private ProductoDAO modelo;
    private ProductoVista vista;

    public ProductoControlador(ProductoDAO modelo, ProductoVista vista) {
        this.modelo = modelo;
        this.vista = vista;
        this.vista.bBuscar.addActionListener(this);
        this.vista.bVer.addActionListener(this);
        
       
    }
    
    public void actionPerformed(ActionEvent e) {
        String accion = e.getActionCommand();
        if(accion.compareTo("BUSCAR")==0) {
            buscar();
        }else {
            if(accion.compareTo("VER")==0) {
                ver();
            }
        }
    }
    
    private void buscar() {
        ProductoVO p = modelo.buscar(Integer.parseInt(vista.txtProducto.getText()));
        if(p==null) {
            System.out.println("ERROR PRODUCTO");
        } else {
            vista.txtNombre.setText(p.getNombre());
            vista.txtPrecio.setText(String.valueOf(p.getPrecio()));
        }

    }
    
    private void ver() {
        ArrayList<ProductoVO> lista = modelo.ver();
        //DefaultTableModel modeloTabla = new DefaultTableModel();
        DefaultTableModel modeloTabla = (DefaultTableModel) vista.tabla.getModel();
        //vista.tabla.setModel(modeloTabla);
        //modeloTabla.addColumn("PRODUCTO");
        //modeloTabla.addColumn("NOMBRE");
        //modeloTabla.addColumn("PRECIO");
        for(ProductoVO p : lista) {
            Object[] o = new Object[3];
            o[0] = p.getProducto();
            o[1] = p.getNombre();
            o[2] = p.getPrecio();
            modeloTabla.addRow(o);
        }
      
    }
}
