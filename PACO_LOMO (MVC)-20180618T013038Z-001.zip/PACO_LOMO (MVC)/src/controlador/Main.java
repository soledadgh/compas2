/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import modelo.ProductoDAO;
import vista.ProductoVista;

/**
 *
 * @author mec
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ProductoDAO m = new ProductoDAO();
        ProductoVista v = new ProductoVista();
        ProductoControlador c = new ProductoControlador(m, v);
        v.setVisible(true);
    }
    
}
