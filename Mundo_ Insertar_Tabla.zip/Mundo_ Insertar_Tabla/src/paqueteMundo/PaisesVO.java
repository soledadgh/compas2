/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqueteMundo;

/**
 *
 * @author Alumno
 */
public class PaisesVO {
    
    private int pais;
    private String nombre;
    private int millones;

    public PaisesVO() {
    }

    
    public PaisesVO(int pais, String nombre, int millones) {
        this.pais = pais;
        this.nombre = nombre;
        this.millones = millones;
    }

    public int getPais() {
        return pais;
    }

    public void setPais(int pais) {
        this.pais = pais;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getMillones() {
        return millones;
    }

    public void setMillones(int millones) {
        this.millones = millones;
    }
    
    
}
