/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.awt.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author mec
 */
public class ProductoDAO {

    
    private Connection conector = null;
    private PreparedStatement sentencia = null;
    private ResultSet resultado = null;
    private String SQL;
    
    public ProductoDAO() {
        conector = new DataBase().getConnection();
    }
    
    
    public ProductoVO buscar(int producto) {
        ProductoVO p = new ProductoVO();
        SQL = "SELECT * FROM productos WHERE producto=?";
        try {
            sentencia = conector.prepareStatement(SQL);
            sentencia.setInt(1, producto);
            resultado = sentencia.executeQuery();
            if(resultado.next()) {
                p.setProducto(resultado.getInt("producto"));
                p.setNombre(resultado.getString("nombre"));
                p.setPrecio(resultado.getBigDecimal("precio"));
            } else {
                
                p = null;
            }
        }catch(SQLException e) {
            System.out.println(e.getMessage());
        }
        
        return p;
    }
    
    public ArrayList<ProductoVO> ver() {
        ArrayList<ProductoVO> lista = new ArrayList<ProductoVO>();
        SQL = "SELECT * FROM productos ORDER BY producto";
        try {
            sentencia = conector.prepareStatement(SQL);
            resultado = sentencia.executeQuery();
            while(resultado.next()) {
                ProductoVO p = new ProductoVO();
                p.setProducto(resultado.getInt("producto"));
                p.setNombre(resultado.getString("nombre"));
                p.setPrecio(resultado.getBigDecimal("precio"));
                lista.add(p);
            }
        }catch(SQLException e) {
            System.out.println(e.getMessage());
        }
        return lista;
    }
}
