/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.math.BigDecimal;

/**
 *
 * @author mec
 */
public class ProductoVO {
    private int producto;
    private String nombre;
    private BigDecimal precio;

    public ProductoVO() {
    }

    public ProductoVO(int producto, String nombre, BigDecimal precio) {
        this.producto = producto;
        this.nombre = nombre;
        this.precio = precio;
    }

    public int getProducto() {
        return producto;
    }

    public void setProducto(int producto) {
        this.producto = producto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public BigDecimal getPrecio() {
        return precio;
    }

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }
    
    
}
